import React from "react";

function Create() {
  return <div></div>;
}

export default Create;
