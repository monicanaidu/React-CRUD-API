import React from "react";

function Pnf() {
  return <div>pnf</div>;
}

export default Pnf;
