import React from "react";

function Update() {
  return <div>update</div>;
}

export default Update;
